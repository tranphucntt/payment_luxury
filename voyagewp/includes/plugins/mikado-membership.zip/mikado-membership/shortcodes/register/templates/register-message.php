<div class="mkdf-register-notice">
	<h5><?php echo esc_html($message); ?></h5>
	<a href="#" class="mkdf-login-action-btn" data-el="#mkdf-login-content" data-title="<?php esc_html_e('Log in', 'mikado-membership'); ?>"><?php esc_html_e('Log in', 'mikado-membership'); ?></a>
</div>