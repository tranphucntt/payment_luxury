<?php
mkdf_tours_reviews_print_review_template();